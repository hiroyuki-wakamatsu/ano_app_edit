from django.apps import AppConfig


class AnoappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "anoapp"
